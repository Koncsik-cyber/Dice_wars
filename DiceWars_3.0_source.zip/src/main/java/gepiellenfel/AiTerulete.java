package main.java.gepiellenfel;

public class AiTerulete {
    public int x,y,z;
    public int hanyadikTerulete;
    public int aiSzama;
    public AiTerulete(int x, int y, int hanyadikTerulete, int aiSzama){
    this.x = x;
    this.y = y;
    this.hanyadikTerulete = hanyadikTerulete;
    this.aiSzama = aiSzama;
    }
}
