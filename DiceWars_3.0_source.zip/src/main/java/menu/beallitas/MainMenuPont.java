package main.java.menu.beallitas;

import main.java.Main;

/**
 * A fömenu pontokat írja ki! számolást nem végez nem hiv meg semmit.
 * @author Koncsik Benedek (G7KJC7)
 */
public class MainMenuPont {
    public MainMenuPont(){
        System.out.println("Beállitások--> 1");
        System.out.println("(Az összes beálitáson végig megy.)");
        System.out.println("Beallitás--> 2");
        System.out.println("(Egyes részeket külön beéállitása.)");
        System.out.println("Játék inditása--> 3");
    }
}
